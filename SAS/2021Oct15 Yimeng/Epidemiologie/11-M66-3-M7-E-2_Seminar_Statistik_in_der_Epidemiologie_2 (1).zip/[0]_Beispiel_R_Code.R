# Workspace leeren
rm(list = ls())

# Die n�chsten drei Auszeilen ausf�hren und # vorher entfernen, falls die Pakete noch
# nicht installiert sind
# install.packages('titanic')
# install.packages('rpart')
# install.packages('rpart.plot')

# Pakete einlesen
library(titanic)        # enth�lt den Titanic Datensatz
library(rpart)          # CART Algorithmus
library(rpart.plot)     # Plotten von B�umen, die mit CART erzeugt wurden

# Der Datensatz hei�t hier titanic_train, wir nennen ihn Titanic
Titanic = titanic_train

# Anzahl Beobachtungen und Variablen
dim(Titanic)

# Kurzer �berblick (erste 6 Beobachtungen und Variablennamen)
head(Titanic)

# Survived hatte die Werte 0 und 1
# Umschreiben in Died und Survived und als kategorielle Variable speichern
Titanic$Survived = factor(Titanic$Survived, labels = c('died', 'survived'))

# �hnlich f�r die Passagierklasse, statt urspr�nglich 1,2,3
Titanic$Pclass = factor(Titanic$Pclass, labels = c("1st", "2nd", "3rd"))

# Seed setzen (wegen Reproduzierbarkeit)
# ein Teil des Algorithmus basiert auf dem Zufall 
# (siehe Cross-Validation in der Vorlesung)
# K�nnt ihr eigentlich ignorieren, aber die cp Werte k�nnen (und werden) sich 
# unterscheiden bei jedem neuen Durchlaufen des Algorithmus
set.seed(76439)

# CART Algorithmus
# formula = Zielgr��e ~ Variablen getrennt durch +
# data = Datensatz, in dem sich Zielgr��e und Variablen befinden
# method = 'class' falls die Zielgr��e kategoriell ist, 
#                  wird aber auch automatisch erkannt
fit = rpart(formula = Survived ~ Pclass + Sex + Age + Parch + SibSp, 
            data = Titanic, method = 'class')

# Plotten des Baumes
# Die Einstellung cex = 1.1 erh�ht hier nur die Schriftgr��e
rpart.plot(fit)

# Detaillierte Auflistung des Ergebnisse
summary(fit)

# Die cost-complexity Parameter Tabelle l�sst sich auch gezielt ausgeben
printcp(fit)

# ...oder einfach plotten (was leichter zu interpretieren ist)
# x-Achse: Cost-complexity Parameter, y-Achse: Cross-Validation Error
# size of tree: ist hier zu interpretieren mit "Anzahl Bl�tter"
# Gestrichelte Linie ist der Minimum Cross-Validation Error + sein Standard Error
#     d.h. w�hle den KLEINSTEN Wert von CP, so dass der 
#     Cross-Validation Error UNTER dieser Linie liegt
plotcp(fit, col = 'blue', lty =23, lwd=2)

# Insbesondere k�nnen wir uns diese f�nf B�ume auch anschauen
# Mit der Funktion prune k�nnen wir den urspr�nglichen Baum "fit" anhand
# des cp-Wertes prunen
fit_1 = prune(fit, cp= 17)        # 1 Blatt, also nur die Wurzel
rpart.plot(fit_1, cex = 1.1)

fit_2 = prune(fit, cp= 0.1)       # 2 Bl�tter
rpart.plot(fit_2, cex = 1.1)

fit_3 = prune(fit, cp= 0.022)     # 3 Bl�tter
rpart.plot(fit_3, cex = 1.1)

fit_4 = prune(fit, cp= 0.019)     # 4 Bl�tter
rpart.plot(fit_4)

fit_5 = prune(fit, cp= 0.013)     # 7 Bl�tter, urspr�nglicher Baum
rpart.plot(fit_5, cex = 1.1)

# Die 1-SE Regel greift also bei cp=0.019
# Wir prunen den Baum "fit"  mit der Funktion prune und nutzen diesen cp-Wert
fit_pruned = prune(fit, cp = 0.019)
rpart.plot(fit_pruned, cex = 1.1)




